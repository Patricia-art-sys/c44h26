# Définir le nom de votre repository(dépôt) dans la variable suivante :
# Ne PAS mettre .git
SET gitHubRepository=
SET gitHubUsername=

C:
cd travail
IF NOT EXIST %gitHubRepository% git clone https://github.com/%gitHubUsername%/%gitHubRepository%
pause